﻿using System;

namespace cSharp25LinearAlgebraFunctions
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
