﻿using MathNet.Numerics.LinearAlgebra;

namespace cSharp25LinearAlgebraFunctions
{
    public class LinearAlgebraFunctions_DirectSolver
    {
        // 1. Standard Least Squares
        public static Vector<double> f1_StandardLeastSquares(Matrix<double> X, Vector<double> y, ref Vector<double> b)
        {
            b = (X.Transpose() * X).Solve(X.Transpose() * y);
            return b;
        }

        // 2. Generalized Least Squares
        public static Vector<double> f2_GeneralizedLeastSquares(Matrix<double> X, Matrix<double> M, Vector<double> y, ref Vector<double> b)
        {
            b = (X.Transpose() * M.Solve(X)).Solve(X.Transpose() * M.Solve(y));
            return b;
        }

        // 3. Optimization [73]
        public static Vector<double> f3_Optimization1(Matrix<double> A, Matrix<double> W, Vector<double> b, Vector<double> c, ref Vector<double> x)
        {
            x = W * (A.Transpose() * (A * W * A.Transpose()).Solve(b) - c);
            return x;
        }

        // 4. Optimization [73]  — returns both (xf, xo)
        public static (Vector<double>, Vector<double>) f4_Optimization2(Matrix<double> A, Matrix<double> W, Vector<double> b, Vector<double> c, Vector<double> x, ref Vector<double> xf, ref Vector<double> xo)
        {
            xf = W * A.Transpose() * (A * W * A.Transpose()).Solve(b - A * x);
            xo = W * (A.Transpose() * (A * W * A.Transpose()).Solve(A * x) - c);
            return (xf, xo);
        }

        // 5. Signal Processing [21]
        public static Vector<double> f5_SignalProcessing(Matrix<double> A, Matrix<double> B, Matrix<double> R, Matrix<double> L, Vector<double> y, Matrix<double> I, ref Vector<double> x)
        {
            x = (A.Transpose().Solve((B.Transpose() * B) * A.Solve(I)) + R.Transpose() * L * R)
                .Solve(A.Transpose().Solve((B.Transpose() * B) * A.Solve(y)));
            return x;
        }

        // 6. Triangular Matrix Inversion [14]
        public static (Matrix<double>, Matrix<double>, Matrix<double>, Matrix<double>) f6_TriangularMatrixInversion(Matrix<double> L00, Matrix<double> L11, Matrix<double> L22, Matrix<double> L10, Matrix<double> L20, Matrix<double> L21, Matrix<double> I00, Matrix<double> I11, // RHS identities for solves
             ref Matrix<double> X10, ref Matrix<double> X20, ref Matrix<double> X11, ref Matrix<double> X21)
        {
            X10 = L10 * L00.Solve(I00);
            X20 = L20 + L22.Solve(L21) * L11.Solve(L10);
            X11 = L11.Solve(I11);
            X21 = -L22.Solve(L21);
            return (X10, X20, X11, X21);
        }

        // 7. Ensemble Kalman Filter [59]
        public static Matrix<double> f7_EnsembleKalmanFilter(Matrix<double> Xb, Matrix<double> B, Matrix<double> H, Matrix<double> R, Matrix<double> Y, Matrix<double> IB, ref Matrix<double> Xa)
        {
            Xa = Xb + (B.Solve(IB) + H.Transpose() * R.Solve(H)).Solve(H.Transpose() * R.Solve(Y - H * Xb));
            return Xa;
        }

        // 8. Ensemble Kalman Filter [59]
        public static Matrix<double> f8_EnsembleKalmanFilterDeltaX(Matrix<double> B, Matrix<double> H, Matrix<double> R, Matrix<double> Y, Matrix<double> Xb, Matrix<double> IB, ref Matrix<double> deltaX)
        {
            deltaX = (B.Solve(IB) + H.Transpose() * R.Solve(H)).Solve(H.Transpose() * R.Solve(Y - H * Xb));
            return deltaX;
        }

        // 9. Ensemble Kalman Filter Variant [59]
        public static Matrix<double> f9_EnsembleKalmanFilterDeltaXVariant(Matrix<double> X, Matrix<double> V, Matrix<double> R, Matrix<double> H, Matrix<double> Y, Matrix<double> Xb, ref Matrix<double> deltaX)
        {
            deltaX = X * V.Transpose() * (R + H * X * (H * X).Transpose()).Solve(Y - H * Xb);
            return deltaX;
        }

        // 10. Image Restoration [74]
        public static Vector<double> f10_ImageRestoration(Matrix<double> H, Vector<double> y, Vector<double> vk_1, Vector<double> uk_1, double lambda, double sigma, Matrix<double> I, ref Vector<double> xk)
        {
            xk = (H.Transpose() * H + (lambda * sigma * sigma * I))
                .Solve(H.Transpose() * y + (lambda * sigma * sigma) * (vk_1 - uk_1));
            return xk;
        }

        // 11. Image Restoration [74] — vectors for y, xk, yk
        public static Vector<double> f11_ImageRestoration(Matrix<double> H, Vector<double> y, Vector<double> xk, Matrix<double> Im, Matrix<double> In, ref Vector<double> yk)
        {
            Matrix<double> Hdagger = H.Transpose() * (H * H.Transpose()).Solve(Im);
            yk = Hdagger * y + (In - Hdagger * H) * xk;
            return yk;
        }

        // 12. Randomized Matrix Inversion [41]
        public static Matrix<double> f12_RandomizedMatrixInversion(Matrix<double> A, Matrix<double> W, Matrix<double> S, Matrix<double> Xk, Matrix<double> I, ref Matrix<double> Xk1)
        {
            Xk1 = Xk + W * A.Transpose() * S * (S.Transpose() * A * W * A.Transpose() * S).Solve(S.Transpose() * (I - A * Xk));
            return Xk1;
        }

        // 13. Randomized Matrix Inversion [41]
        public static Matrix<double> f13_RandomizedMatrixInversion(Matrix<double> A, Matrix<double> W, Matrix<double> S, Matrix<double> Xk, Matrix<double> I, ref Matrix<double> Xk1)
        {
            Matrix<double> Lambda = S * (S.Transpose() * A.Transpose() * W * A * S).Solve(S.Transpose());
            Xk1 = Xk + (I - Xk * A.Transpose()) * Lambda * A.Transpose() * W;
            return Xk1;
        }

        // 14. Randomized Matrix Inversion [41]
        public static Matrix<double> f14_RandomizedMatrixInversion(Matrix<double> A, Matrix<double> W, Matrix<double> S, Matrix<double> Xk, Matrix<double> I, ref Matrix<double> Xk1)
        {
            Matrix<double> Lambda = S * (S.Transpose() * A * W * A * S).Solve(S.Transpose());
            Matrix<double> Theta = Lambda * A * W;
            Matrix<double> Mk = Xk * A - I;
            Xk1 = Xk - Mk * Theta - (Mk * Theta).Transpose() + Theta.Transpose() * (A * Xk * A - A) * Theta;
            return Xk1;
        }

        // 15. Randomized Matrix Inversion [41]
        public static Matrix<double> f15_RandomizedMatrixInversion(Matrix<double> A, Matrix<double> S, Matrix<double> Xk, Matrix<double> I, ref Matrix<double> Xk1)
        {
            Matrix<double> ASinv = (S.Transpose() * A * S).Solve(S.Transpose());
            Xk1 = S * ASinv + (I - S * ASinv * A) * Xk * (I - A * S * ASinv);
            return Xk1;
        }

        // 16. Stochastic Newton [19]
        public static Matrix<double> f16_StochasticNewton(double k, Matrix<double> Bk_1, Matrix<double> A, Matrix<double> Wk, Matrix<double> Il, Matrix<double> In, ref Matrix<double> Bk)
        {
            Bk = (k / (k - 1.0)) * Bk_1 * (In - A.Transpose() * Wk *
                 ((k - 1.0) * Il + Wk.Transpose() * A * Bk_1 * A.Transpose() * Wk)
                 .Solve(Wk.Transpose() * A * Bk_1));
            return Bk;
        }

        // 17. Stochastic Newton [19]
        public static Matrix<double> f17_StochasticNewton(Matrix<double> A, Matrix<double> W1, double lambda1, Matrix<double> In, Matrix<double> Il, ref Matrix<double> B1)
        {
            B1 = (1.0 / lambda1) * (In - A.Transpose() * W1 *
                 (lambda1 * Il + W1.Transpose() * A * A.Transpose() * W1).Solve(W1.Transpose() * A));
            return B1;
        }

        //18. Tikhonov regularization[37] — vectors
        public static Vector<double> f18_TikhonovRegularization(Matrix<double> A, Matrix<double> Gamma, Vector<double> b, ref Vector<double> x)
        {
            x = (A.Transpose() * A + Gamma.Transpose() * Gamma).Solve(A.Transpose() * b);
            return x;
        }

        // 19. Tikhonov regularization [37] — vectors
        public static Vector<double> f19_TikhonovRegularization(Matrix<double> A, double alpha, Matrix<double> I, Vector<double> b, ref Vector<double> x)
        {
            x = (A.Transpose() * A + alpha * alpha * I).Solve(A.Transpose() * b);
            return x;
        }

        // 20. Generalized Tikhonov regularization — vectors
        public static Vector<double> f20_GeneralizedTikhonov(Matrix<double> A, Matrix<double> P, Matrix<double> Q, Vector<double> b, Vector<double> x0, ref Vector<double> x)
        {
            x = (A.Transpose() * P * A + Q).Solve(A.Transpose() * P * b + Q * x0);
            return x;
        }

        // 21. Generalized Tikhonov regularization — vectors
        public static Vector<double> f21_GeneralizedTikhonov(Matrix<double> A, Matrix<double> P, Matrix<double> Q, Vector<double> b, Vector<double> x0, ref Vector<double> x)
        {
            x = x0 + (A.Transpose() * P * A + Q).Solve(A.Transpose() * P * (b - A * x0));
            return x;
        }

        // 22. LMMSE estimator [52] — vectors
        public static Vector<double> f22_LMMSEEstimator(Matrix<double> A, Matrix<double> CX, Matrix<double> CZ, Vector<double> y, Vector<double> x, ref Vector<double> xout)
        {
            xout = CX * A.Transpose() * (A * CX * A.Transpose() + CZ).Solve(y - A * x) + x;
            return xout;
        }

        // 23. LMMSE estimator [52] — vectors
        public static Vector<double> f23_LMMSEEstimator2(Matrix<double> A, Matrix<double> CX, Matrix<double> CZ, Vector<double> y, Vector<double> x, ref Vector<double> xout)
        {
            xout = (A.Transpose() * CZ.Solve(A) + CX.Inverse()).Solve(A.Transpose() * CZ.Solve(y - A * x)) + x;
            return xout;
        }

        // 24. LMMSE Estimator [52] — xt,y,xt1 are vectors
        public static (Matrix<double>, Vector<double>, Matrix<double>) f24_LMMSEEstimator3(Matrix<double> A, Matrix<double> Ct, Matrix<double> CZ, Vector<double> xt, Vector<double> y, Matrix<double> I_m, Matrix<double> I_n, ref Matrix<double> Kt1, ref Vector<double> xt1, ref Matrix<double> Ct1)
        {
            Kt1 = Ct * A.Transpose() * (A * Ct * A.Transpose() + CZ).Solve(I_m);
            xt1 = xt + Kt1 * (y - A * xt);
            Ct1 = (I_n - Kt1 * A) * Ct;
            return (Kt1, xt1, Ct1);
        }

        // 25. Kalman Filter [53] — xk_1, zk, xk are vectors
        public static (Matrix<double>, Matrix<double>, Vector<double>) f25_KalmanFilter(Matrix<double> Pk_1, Matrix<double> Hk, Matrix<double> Rk, Vector<double> xk_1, Vector<double> zk, Matrix<double> I_n, Matrix<double> I_m, ref Matrix<double> Kk, ref Matrix<double> Pk, ref Vector<double> xk)
        {
            Kk = Pk_1 * Hk.Transpose() * (Hk * Pk_1 * Hk.Transpose() + Rk).Solve(I_m);
            Pk = (I_n - Kk * Hk) * Pk_1;
            xk = xk_1 + Kk * (zk - Hk * xk_1);
            return (Kk, Pk, xk);
        }
    }
}
